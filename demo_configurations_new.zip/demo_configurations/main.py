# main.py
import csv
import os
import subprocess
import time


# def get_csv_reader(filename):
#     with open(filename) as csv_file:
#         reader = csv.reader(csv_file, delimiter=',')
#         return reader

def get_headers(filename):
    with open(filename) as csv_file:
        reader = csv.reader(csv_file, delimiter=',')
        for row in reader:
            if reader.line_num == 1:
                return row
                break


def get_column_index(filename, col_name):
    with open(filename) as csv_file:
        reader = csv.reader(csv_file, delimiter=',')
        for row in reader:
            for idx, x in enumerate(row):
                if col_name == x:
                    return idx
            break


def get_column_data(filename, index):
    col_data = []
    with open(filename) as csv_file:
        reader = csv.reader(csv_file, delimiter=',')
        next(reader)
        for row in reader:
            col_data.append(row[index])
    return col_data


def get_total_files_to_execute(filename):
    res = []
    for x in get_headers(filename):
        if x.__contains__("Test_Data"):
            pass
        else:
            res.append(x)
    return res


def get_data_rows_to_execute(filename, pat):
    pat = pat.split(".")
    for x in get_headers(filename):
        if x.__contains__(pat[0] + "_Test_Data"):
            return x


fn = "/home/inchara/Downloads/demo_configurations/Test_Suite.csv"


def get_cwd():
    return os.getcwd()


def run_pytest():
    for x in get_total_files_to_execute(fn):
        res = get_data_rows_to_execute(fn, x)
        if res == None:
            test_methods_without_data = get_column_data(fn, get_column_index(fn, x))
            for zz in test_methods_without_data:
                if len(zz) != 0:
                    cmd = f"pytest -rA -q -s --html=./reports/report_$(date +'%Y%m%d_%H%M%S').html {get_cwd()}/tests/{x}::{zz}"
                    subprocess.run(cmd, shell=True)
                    time.sleep(2)
                    print("Data is not available for", x)
        elif (len(res) != 0):
            test_methods_with_data = get_column_data(fn, get_column_index(fn, x))
            test_data = get_column_data(fn, get_column_index(fn, res))
            print(test_methods_with_data)
            print(test_data)
            print(get_column_index(fn, res))
            # for xx in test_methods_with_data:
            for i, xx in enumerate(test_methods_with_data):
                # for yy in test_data:
                yy = test_data
                print("yyyyyyyy", yy[i])
                if yy[i].__contains__(","):
                    yy_res = yy[i].split(",")
                    for yyy in yy_res:
                        cmd = (f"pytest -rA -q -s --html=./reports/report_$(date +'%Y%m%d_%H%M%S').html "
                               f"--additional_arguments {yyy} {get_cwd()}/tests/{x}::{xx}")
                        print("cmd is ", cmd)
                        subprocess.run(cmd, shell=True)
                        time.sleep(2)
                else:
                    cmd = (f"pytest -rA -q -s --html=./reports/report_$(date +'%Y%m%d_%H%M%S').html "
                           f"--additional_arguments {yy[i]} {get_cwd()}/tests/{x}::{xx}")
                    print("cmd is ", cmd)
                    subprocess.run(cmd, shell=True)
                    time.sleep(2)


if __name__ == "__main__":
    run_pytest()
