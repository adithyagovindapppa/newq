import csv

import pytest


def test_hello(setup_option):
    assert "hello" == "hello"
