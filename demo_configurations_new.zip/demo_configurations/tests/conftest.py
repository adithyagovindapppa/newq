import pytest

pytest.name = None


def pytest_addoption(parser):
    parser.addoption('--additional_arguments', action='store', help='some helptext')


@pytest.fixture(scope="session", autouse=True)
def setup_option(request):
    args = request.config.getoption("--additional_arguments")
    pytest.name = args
