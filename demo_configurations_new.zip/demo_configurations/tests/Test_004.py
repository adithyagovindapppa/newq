import csv

import pytest


def read_csv(fn,id):
    with open(fn) as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        reader = csv.reader(csvfile)
        next(reader)  # skipping the first row
        for row in csvReader:
            if (row[0] == id):
                return row


def test_multiplication(setup_option):
    input_data = read_csv('/home/devaraja/Documents/configuration/TestData/Test_Multiplication.csv',pytest.name)
    # print("input_data[1]",int(input_data[1]))
    # print("int(input_data[2]",int(input_data[2]))
    # print("int(input_data[3]", int(input_data[3]))
    assert int(input_data[1]) * int(input_data[2]) == int(input_data[3])


def test_division(setup_option):
    input_data = read_csv('/home/devaraja/Documents/configuration/TestData/Test_Division.csv',pytest.name)
    assert int(input_data[1]) / int(input_data[2]) == int(input_data[3])
