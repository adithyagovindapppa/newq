import csv
import time

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By


def read_csv(fn, id):
    with open(fn) as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        reader = csv.reader(csvfile)
        next(reader)  # skipping the first row
        for row in csvReader:
            if row[0] == id:
                return row


def test_login(setup_option):
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(options=chrome_options)
    driver.get("https://practicetestautomation.com/practice-test-login/")
    driver.maximize_window()
    time.sleep(5)
    input_data = read_csv('/home/inchara/Downloads/demo_configurations/TestData/Test_Login.csv', pytest.name)
    driver.find_element(By.NAME, "username").send_keys(input_data[1])
    driver.find_element(By.NAME, "password").send_keys(input_data[2])
    time.sleep(3)
    driver.find_element(By.XPATH, "//*[@id='submit']").click()
    time.sleep(3)


def test_logout(setup_option):
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(options=chrome_options)
    driver.get("https://practicetestautomation.com/practice-test-login/")
    driver.maximize_window()
    time.sleep(5)
    input_data = read_csv('/home/inchara/Downloads/demo_configurations/TestData/Test_Logout.csv', pytest.name)
    driver.find_element(By.NAME, "username").send_keys(input_data[1])
    driver.find_element(By.NAME, "password").send_keys(input_data[2])
    time.sleep(3)
    driver.find_element(By.XPATH, "//*[@id='submit']").click()
    time.sleep(3)
    driver.find_element(By.XPATH, "//*[@id='loop-container']/div/article/div[2]/div/div/div/a").click()


def test_world(setup_option):
    assert "1" == "1"

